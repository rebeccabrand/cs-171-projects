console.log("let's get started!")

d3.csv("data/buildings.csv").then(function(data) {
    console.log(data);
});

d3.csv("data/buildings.csv", function(d) {
    return {
        building: d.building, // Keep string data
        city: d.city, // Same
        completed: parseFloat(d.completed), // Convert string to float
        country: d.country, // Keep string data
        floors: parseFloat(d.floors), // Convert string to float
        height_m: parseFloat(d.height_m), // Same
        height_ft: parseFloat(d.height_ft), // Same
        height_px: parseFloat(d.height_px), // Same
        image: d.image
    };
}).then((data)=> {
    let sortedBuildingsData = data.sort( (a, b) => {
        return b.height_m - a.height_m;
    })

    // Set global variable for building stats
    console.log(sortedBuildingsData);

    // Add svg element (drawing space)
    let svg = d3.select("#left-column")
        .append("svg")
        .attr("width", 500)
        .attr("height", 500)

    // Add rectangles and bind the data
    svg.selectAll("rect")
        .data(sortedBuildingsData)
        .enter()
        .append("rect")
        .classed("bar-chart", true)
        .attr("x", 250)
        .attr("y", (d, i) => i * 50)
        .attr("width", (d) => (d.height_m) / 3)
        .attr("height", 30)
        .style("fill", "white")

    // Add text
    svg.selectAll("text")
        .data(sortedBuildingsData)
        .enter()
        .append("text")
        .classed("building-label", true)
        .text((d) => d.building)
        .attr("x", 50)
        .attr("y", (d, i) => i * 50)
        .attr("text-anchor", "end")
        .attr("width", 150)
        .style("font-size", "10")
});