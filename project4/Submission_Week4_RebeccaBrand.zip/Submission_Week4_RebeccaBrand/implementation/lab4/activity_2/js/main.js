console.log("let's get started!")

let sandwiches = [
    { name: "Thesis", price: 7.95, size: "large" },
    { name: "Dissertation", price: 8.95, size: "large" },
    { name: "Highlander", price: 6.50, size: "small" },
    { name: "Just Tuna", price: 6.50, size: "small" },
    { name: "So-La", price: 7.95, size: "large" },
    { name: "Special", price: 12.50, size: "small" }
];

// Add svg element (drawing space)
let svg = d3.select("body").append("svg")
    .attr("width", 1000)
    .attr("height", 500);

// Add circles
svg.selectAll("circle")
    .data(sandwiches)
    .enter()
    .append("circle")
    .style("cy", 50)
    .style("cx", (d, i) => i * 50)
    .style("stroke", "black")
    .style("stroke-width", 2)
    .style("r", d => {
        if (d.size === "small")
            return (10);
        else
            return (20);
    })
    .style("fill", d => {
        if (d.price < 7.00)
            return "yellow";
        else
            return "green";
    });

d3.csv("data/sandwiches.csv").then(function(data) {
    console.log(data); // [{name: "Thesis", price: "7.95", size: "large"},..]
});
console.log(`look at that: The browser already interpreted this line, while it's still waiting for the data to load`)