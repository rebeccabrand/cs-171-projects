console.log("let's get started!")

// Activity 1

d3.select("#left-col").append("div").text("Dynamic Content");

let states = ["Connecticut", "Maine", "Massachusetts", "New Hampshire", "Rhode Island", "Vermont"];

let p = d3.select("#left-col-1").selectAll("p")
    .data(states)
    .enter()
    .append("p")
    .text(d => d)
    .attr("class", "custom-paragraph")
        .style("color", "blue")
        .style("font-weight", d => {
            if(d === "Massachusetts")
                return "bold";
            else
                return "normal";
        });

let numericData = [1, 2, 4, 8, 16];

// Add svg element (drawing space)
let svg = d3.select("body").append("svg")
    .attr("width", 300)
    .attr("height", 50);

// Add rectangle
svg.selectAll("rect")
    .data(numericData)
    .enter()
    .append("rect")
    .attr("fill", "red")
    .attr("width", 50)
    .attr("height", 50)
    .attr("y", 0)
    .attr("x", (d, i) => i * 60)