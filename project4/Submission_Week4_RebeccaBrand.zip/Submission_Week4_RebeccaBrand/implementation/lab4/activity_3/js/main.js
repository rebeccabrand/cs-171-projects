// Main JS file for Activity 3

console.log("let's get started!")

/* Write the cities data to the web console and inspect in the browser
d3.csv("data/cities.csv").then(function(data) {
    console.log(data);
}); */

d3.csv("data/cities.csv", function(d) {
    return {
        country: d.country, // Same
        city: d.city, // Same
        eu: d.eu, // Same
        population: parseFloat(d.population), // Convert string to float
        x: parseFloat(d.x), // String to float
        y: parseFloat(d.y), // String to float
    };
}).then((data)=> {
    let countryDataEU = data.filter((value, index, countryDataEU) => {
        return (value.eu === "true");
    });
    console.log(countryDataEU);

    d3.select("body")
        .append("p")
        .text("Number of Countries: " + countryDataEU.length);

    d3.select("p")
        .style("font-weight", "bold")
        .style("font-size", "20px")
    /* let p = d3.select("body").selectAll("p")
        .data(countryDataEU)
        .enter()
        .append("p")
        .text(countryDataEU.length) */

    // Add svg element (drawing space)
    let svg = d3.select("body").append("svg")
        .attr("width", 700)
        .attr("height", 550);

    // Add circles
    svg.selectAll("circle")
        .data(countryDataEU)
        .enter()
        .append("circle")
        .attr("cy", (d) => d.y)
        .attr("cx", (d) => d.x)
        .style("fill", "green")
        .attr("r", d => {
            if (d.population < 1000000)
                return (4);
            else
                return (8);
        })
        .on("mouseover", function(event, d){  // Add event listener
            console.log('check out what you have access to', event, d, this)
            d3.select(this)
                .transition()
                .style("fill", "brown")
        })
        .on("mouseout", function(d) {
            d3.select(this)
            .transition()
            .style("fill", "green")
        });

    // Add text
    svg.selectAll("text")
        .data(countryDataEU)
        .enter()
        .append("text")
        .classed("city-label", true)
        .attr("x", (d) => d.x)
        .attr("y", (d) => (d.y - 12))
        .text((d) => {
            if (d.population > 1000000)
                return (d.city)
            else
                return ("");
        })
        .on("click", function(event, d){  // Add event listener
            console.log('check out what you have access to', event, d, this)
            d3.select(this)
                .transition()
                .text(d.city + ", Pop." + d.population)
        });

});
